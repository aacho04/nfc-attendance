<?php
include '../includes/db.php';
include '../includes/functions.php';
if (!is_admin()) redirect('../dashboard.php');

$teachers = $pdo->query("SELECT t.id, t.name FROM teachers t")->fetchAll();
$classes = $pdo->query("SELECT id, name FROM classes")->fetchAll();
$subjects = $pdo->query("SELECT id, name FROM subjects")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['create_class'])) {
        $stmt = $pdo->prepare("INSERT INTO classes (name) VALUES (?)");
        $stmt->execute([$_POST['class_name']]);
        redirect('assign_subject.php');
    } elseif (isset($_POST['create_subject'])) {
        $stmt = $pdo->prepare("INSERT INTO subjects (name) VALUES (?)");
        $stmt->execute([$_POST['subject_name']]);
        redirect('assign_subject.php');
    } else {
        $teacher_id = $_POST['teacher_id'];
        $subject_id = $_POST['subject_id'];
        $class_id = $_POST['class_id'];
        
        $stmt = $pdo->prepare("INSERT INTO assignments (teacher_id, subject_id, class_id) VALUES (?, ?, ?)");
        $stmt->execute([$teacher_id, $subject_id, $class_id]);
        $success = "Assigned";
    }
}

include '../includes/header.php';
?>
<h1 class="text-2xl">Assign Subject</h1>
<?php if (isset($success)): ?><p class="text-green-500"><?php echo $success; ?></p><?php endif; ?>
<form method="POST" class="space-y-4">
    <select name="teacher_id" class="border p-2 w-full" required>
        <?php foreach ($teachers as $t): ?>
            <option value="<?php echo $t['id']; ?>"><?php echo $t['name']; ?></option>
        <?php endforeach; ?>
    </select>
    <select name="subject_id" class="border p-2 w-full" required>
        <?php foreach ($subjects as $s): ?>
            <option value="<?php echo $s['id']; ?>"><?php echo $s['name']; ?></option>
        <?php endforeach; ?>
    </select>
    <select name="class_id" class="border p-2 w-full" required>
        <?php foreach ($classes as $c): ?>
            <option value="<?php echo $c['id']; ?>"><?php echo $c['name']; ?></option>
        <?php endforeach; ?>
    </select>
    <button type="submit" class="bg-blue-500 text-white p-2">Assign</button>
</form>

<h2 class="text-xl mt-4">Create Class</h2>
<form method="POST" action="" class="space-y-4">
    <input type="hidden" name="create_class" value="1">
    <input type="text" name="class_name" placeholder="Class Name" class="border p-2 w-full" required>
    <button type="submit" class="bg-blue-500 text-white p-2">Create Class</button>
</form>

<h2 class="text-xl mt-4">Create Subject</h2>
<form method="POST" action="" class="space-y-4">
    <input type="hidden" name="create_subject" value="1">
    <input type="text" name="subject_name" placeholder="Subject Name" class="border p-2 w-full" required>
    <button type="submit" class="bg-blue-500 text-white p-2">Create Subject</button>
</form>
<?php include '../includes/footer.php'; ?>