<?php
include 'includes/functions.php';
session_destroy();
redirect('login.php');
?>