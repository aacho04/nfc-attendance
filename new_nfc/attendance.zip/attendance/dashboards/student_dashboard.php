<?php
include '../includes/db.php';
include '../includes/functions.php';
if (!is_student()) redirect('../login.php');

include '../includes/header.php';
?>
<h1 class="text-2xl">Student Dashboard</h1>
<p>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>! Ask your teacher to mark your attendance.</p>
<p>Attendance is marked via URL (e.g., ?student_id=your_id) on the teacher's device.</p>
<?php include '../includes/footer.php'; ?>