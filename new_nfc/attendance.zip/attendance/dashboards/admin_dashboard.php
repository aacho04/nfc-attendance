<?php
include '../includes/db.php';
include '../includes/functions.php';
if (!is_admin()) redirect('../login.php');

$teachers = $pdo->query("SELECT t.id, t.name FROM teachers t")->fetchAll();
$classes = $pdo->query("SELECT DISTINCT id, name FROM classes")->fetchAll();
$subjects = $pdo->query("SELECT id, name FROM subjects")->fetchAll();

include '../includes/header.php';
?>
<h1 class="text-2xl">Admin Dashboard</h1>
<p>Welcome, Admin! Manage users, classes, and assignments.</p>
<div class="space-y-4">
    <h2 class="text-xl">Assign Subject</h2>
    <form method="POST" action="../assign_subject.php" class="space-y-4">
        <select name="teacher_id" class="border p-2 w-full" required>
            <?php foreach ($teachers as $t): ?>
                <option value="<?php echo $t['id']; ?>"><?php echo $t['name']; ?></option>
            <?php endforeach; ?>
        </select>
        <select name="subject_id" class="border p-2 w-full" required>
            <?php foreach ($subjects as $s): ?>
                <option value="<?php echo $s['id']; ?>"><?php echo $s['name']; ?></option>
            <?php endforeach; ?>
        </select>
        <select name="class_id" class="border p-2 w-full" required>
            <?php foreach ($classes as $c): ?>
                <option value="<?php echo $c['id']; ?>"><?php echo $c['name']; ?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="bg-blue-500 text-white p-2">Assign</button>
    </form>
    <h2 class="text-xl mt-4">Create Class</h2>
    <form method="POST" action="../assign_subject.php" class="space-y-4">
        <input type="hidden" name="create_class" value="1">
        <input type="text" name="class_name" placeholder="Class Name" class="border p-2 w-full" required>
        <button type="submit" class="bg-blue-500 text-white p-2">Create Class</button>
    </form>
    <h2 class="text-xl mt-4">Create Subject</h2>
    <form method="POST" action="../assign_subject.php" class="space-y-4">
        <input type="hidden" name="create_subject" value="1">
        <input type="text" name="subject_name" placeholder="Subject Name" class="border p-2 w-full" required>
        <button type="submit" class="bg-blue-500 text-white p-2">Create Subject</button>
    </form>
</div>
<?php include '../includes/footer.php'; ?>