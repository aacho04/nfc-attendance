<?php
include '../includes/db.php';
include '../includes/functions.php';
if (!is_teacher()) redirect('../login.php');

// Fetch username from database using user_id
$username = 'Unknown Teacher'; // Default fallback
try {
    $stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    if ($user) {
        $username = htmlspecialchars($user['username']);
    }
} catch (PDOException $e) {
    error_log("Error fetching username: " . $e->getMessage());
}

// Fetch attendance data for graphs with class filter
$lecture_data = [];
$selected_class = isset($_GET['class_id']) ? $_GET['class_id'] : '';
$teacher_id = $_SESSION['user_id'];
try {
    $query = "SELECT l.id AS lecture_id, l.start_time, c.name AS class_name, COUNT(att.id) AS attended, 
              (SELECT COUNT(*) FROM students s WHERE s.class_id = c.id) AS total_students
              FROM teachers t
              JOIN assignments a ON t.id = a.teacher_id
              JOIN classes c ON a.class_id = c.id
              JOIN lectures l ON a.id = l.assignment_id
              LEFT JOIN attendances att ON l.id = att.lecture_id
              WHERE t.user_id = ? AND l.end_time IS NOT NULL";
    $params = [$teacher_id];
    if ($selected_class) {
        $query .= " AND c.id = ?";
        $params[] = $selected_class;
    }
    $query .= " GROUP BY l.id, l.start_time, c.name, c.id
                ORDER BY l.start_time DESC
                LIMIT 5";
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $lectures = $stmt->fetchAll();
    foreach ($lectures as $lecture) {
        $attendance_rate = $lecture['total_students'] > 0 ? round(($lecture['attended'] / $lecture['total_students']) * 100, 2) : 0;
        $lecture_data[] = [
            'label' => "Lecture " . $lecture['lecture_id'] . " (" . date('Y-m-d', strtotime($lecture['start_time'])) . ")",
            'class' => $lecture['class_name'],
            'attendance' => $attendance_rate
        ];
    }
} catch (PDOException $e) {
    error_log("Error fetching lecture data: " . $e->getMessage());
    $lecture_data = []; // Ensure it's an array even on error
}

include '../includes/header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard | Attendance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary: #4361ee;
            --primary-light: #4895ef;
            --secondary: #3f37c9;
            --success: #4cc9f0;
            --danger: #f72585;
            --warning: #f8961e;
            --info: #4895ef;
            --light: #f8f9fa;
            --dark: #212529;
            --gray: #6c757d;
            --light-gray: #e9ecef;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f7fb;
            color: var(--dark);
            line-height: 1.6;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Header Styles */
        header {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            padding: 20px 0;
            border-radius: var(--border-radius);
            margin-bottom: 30px;
            box-shadow: var(--box-shadow);
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }

        .welcome-section h1 {
            font-size: 2.2rem;
            margin-bottom: 5px;
        }

        .welcome-section p {
            opacity: 0.9;
            font-size: 1.1rem;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .avatar {
            width: 50px;
            height: 50px;
            background-color: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
        }

        /* Quick Actions */
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .action-card {
            background: white;
            border-radius: var(--border-radius);
            padding: 25px;
            text-align: center;
            box-shadow: var(--box-shadow);
            transition: var(--transition);
            cursor: pointer;
        }

        .action-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
        }

        .action-card i {
            font-size: 2.5rem;
            margin-bottom: 15px;
            color: var(--primary);
        }

        .action-card h3 {
            font-size: 1.3rem;
            margin-bottom: 10px;
            color: var(--dark);
        }

        .action-card p {
            color: var(--gray);
            margin-bottom: 15px;
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: var(--primary);
            color: white;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 600;
            transition: var(--transition);
        }

        .btn:hover {
            background: var(--secondary);
        }

        /* Dashboard Grid */
        .dashboard-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 25px;
        }

        @media (max-width: 1024px) {
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
        }

        /* Card Styles */
        .card {
            background: white;
            border-radius: var(--border-radius);
            padding: 25px;
            box-shadow: var(--box-shadow);
            margin-bottom: 25px;
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--light-gray);
        }

        .card-header h2 {
            font-size: 1.5rem;
            color: var(--dark);
        }

        .card-header a {
            color: var(--primary);
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
        }

        /* Stats Cards */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: var(--border-radius);
            padding: 20px;
            box-shadow: var(--box-shadow);
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
        }

        .stat-info h3 {
            font-size: 1.8rem;
            margin-bottom: 5px;
        }

        .stat-info p {
            color: var(--gray);
            font-size: 0.9rem;
        }

        /* Chart Container */
        .chart-container {
            height: 300px;
            position: relative;
        }

        /* Recent Activity */
        .activity-list {
            list-style: none;
        }

        .activity-item {
            display: flex;
            align-items: center;
            padding: 15px 0;
            border-bottom: 1px solid var(--light-gray);
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 1.2rem;
        }

        .activity-content {
            flex: 1;
        }

        .activity-content h4 {
            margin-bottom: 5px;
            font-size: 1rem;
        }

        .activity-content p {
            color: var(--gray);
            font-size: 0.9rem;
        }

        .activity-time {
            color: var(--gray);
            font-size: 0.8rem;
        }

        /* Footer */
        footer {
            text-align: center;
            padding: 20px;
            margin-top: 40px;
            color: var(--gray);
            font-size: 0.9rem;
        }

        .no-data {
            text-align: center;
            padding: 40px 20px;
            color: var(--gray);
        }

        .no-data i {
            font-size: 3rem;
            margin-bottom: 15px;
            opacity: 0.5;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <div class="header-content">
                <div class="welcome-section">
                    <h1>Teacher Dashboard</h1>
                    <p>Welcome back, <span id="username"><?php echo isset($username) ? $username : 'Teacher'; ?></span>! Here's your teaching overview.</p>
                </div>
                <div class="user-info">
                    <div class="avatar">
                        <i class="fas fa-chalkboard-teacher"></i>
                    </div>
                    <div>
                        <div id="username-display"><?php echo isset($username) ? $username : 'Teacher'; ?></div>
                        <div style="font-size: 0.9rem; opacity: 0.8;">Teacher</div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Quick Actions -->
        <div class="quick-actions">
            <div class="action-card" onclick="location.href='../teacher/start_lecture.php'">
                <i class="fas fa-play-circle"></i>
                <h3>Start Lecture</h3>
                <p>Begin a new lecture session for your class</p>
                <span class="btn">Start Now</span>
            </div>
            <div class="action-card" onclick="location.href='../teacher/end_lecture.php'">
                <i class="fas fa-stop-circle"></i>
                <h3>End Lecture</h3>
                <p>Conclude the current lecture session</p>
                <span class="btn">End Now</span>
            </div>
            <div class="action-card" onclick="location.href='../student/mark_attendance.php'">
                <i class="fas fa-clipboard-check"></i>
                <h3>Mark Attendance</h3>
                <p>Take attendance for your current lecture</p>
                <span class="btn">Mark Now</span>
            </div>
        </div>

        <!-- Stats Overview -->
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-icon" style="background-color: rgba(67, 97, 238, 0.1); color: var(--primary);">
                    <i class="fas fa-chalkboard"></i>
                </div>
                <div class="stat-info">
                    <h3 id="total-lectures"><?php echo count($lecture_data); ?></h3>
                    <p>Total Lectures</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background-color: rgba(76, 201, 240, 0.1); color: var(--success);">
                    <i class="fas fa-user-check"></i>
                </div>
                <div class="stat-info">
                    <h3 id="avg-attendance">
                        <?php 
                        if (!empty($lecture_data)) {
                            $total_attendance = 0;
                            foreach ($lecture_data as $lecture) {
                                $total_attendance += $lecture['attendance'];
                            }
                            echo round($total_attendance / count($lecture_data), 1) . '%';
                        } else {
                            echo '0%';
                        }
                        ?>
                    </h3>
                    <p>Average Attendance</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background-color: rgba(248, 150, 30, 0.1); color: var(--warning);">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-info">
                    <h3 id="total-students"><?php echo !empty($lecture_data) ? '142' : '0'; ?></h3>
                    <p>Total Students</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background-color: rgba(247, 37, 133, 0.1); color: var(--danger);">
                    <i class="fas fa-calendar-alt"></i>
                </div>
                <div class="stat-info">
                    <h3 id="active-classes"><?php echo !empty($lecture_data) ? '4' : '0'; ?></h3>
                    <p>Active Classes</p>
                </div>
            </div>
        </div>

        <!-- Main Dashboard Content -->
        <div class="dashboard-grid">
            <!-- Left Column -->
            <div class="left-column">
                <!-- Attendance Chart -->
                <div class="card">
                    <div class="card-header">
                        <h2>Attendance Overview</h2>
                        <a href="../teacher/reports.php">View Full Report</a>
                    </div>
                    <div class="chart-container">
                        <?php if (empty($lecture_data)): ?>
                            <div class="no-data">
                                <i class="fas fa-chart-bar"></i>
                                <h3>No Data Available</h3>
                                <p>Start a lecture and mark attendance to see reports.</p>
                            </div>
                        <?php else: ?>
                            <canvas id="attendanceChart"></canvas>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Recent Lectures -->
                <div class="card">
                    <div class="card-header">
                        <h2>Recent Lectures</h2>
                        <a href="../teacher/lectures.php">View All</a>
                    </div>
                    <div class="chart-container">
                        <?php if (empty($lecture_data)): ?>
                            <div class="no-data">
                                <i class="fas fa-chalkboard"></i>
                                <h3>No Lectures Found</h3>
                                <p>Start your first lecture to see data here.</p>
                            </div>
                        <?php else: ?>
                            <canvas id="lecturesChart"></canvas>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Right Column -->
            <div class="right-column">
                <!-- Upcoming Schedule -->
                <div class="card">
                    <div class="card-header">
                        <h2>Today's Schedule</h2>
                        <a href="../teacher/schedule.php">Full Schedule</a>
                    </div>
                    <ul class="activity-list">
                        <li class="activity-item">
                            <div class="activity-icon" style="background-color: rgba(67, 97, 238, 0.1); color: var(--primary);">
                                <i class="fas fa-clock"></i>
                            </div>
                            <div class="activity-content">
                                <h4>Mathematics - Algebra</h4>
                                <p>10:00 AM - 11:30 AM</p>
                            </div>
                            <div class="activity-time">Room 204</div>
                        </li>
                        <li class="activity-item">
                            <div class="activity-icon" style="background-color: rgba(76, 201, 240, 0.1); color: var(--success);">
                                <i class="fas fa-clock"></i>
                            </div>
                            <div class="activity-content">
                                <h4>Physics - Mechanics</h4>
                                <p>1:00 PM - 2:30 PM</p>
                            </div>
                            <div class="activity-time">Lab 3</div>
                        </li>
                        <li class="activity-item">
                            <div class="activity-icon" style="background-color: rgba(248, 150, 30, 0.1); color: var(--warning);">
                                <i class="fas fa-clock"></i>
                            </div>
                            <div class="activity-content">
                                <h4>Office Hours</h4>
                                <p>3:00 PM - 4:30 PM</p>
                            </div>
                            <div class="activity-time">Office 302</div>
                        </li>
                    </ul>
                </div>

                <!-- Recent Activity -->
                <div class="card">
                    <div class="card-header">
                        <h2>Recent Activity</h2>
                        <a href="../teacher/activity.php">See All</a>
                    </div>
                    <ul class="activity-list">
                        <li class="activity-item">
                            <div class="activity-icon" style="background-color: rgba(76, 201, 240, 0.1); color: var(--success);">
                                <i class="fas fa-user-check"></i>
                            </div>
                            <div class="activity-content">
                                <h4>Attendance Marked</h4>
                                <p>Physics Lecture - 32 students present</p>
                            </div>
                            <div class="activity-time">2 hours ago</div>
                        </li>
                        <li class="activity-item">
                            <div class="activity-icon" style="background-color: rgba(67, 97, 238, 0.1); color: var(--primary);">
                                <i class="fas fa-chalkboard"></i>
                            </div>
                            <div class="activity-content">
                                <h4>Lecture Started</h4>
                                <p>Mathematics - Algebra class</p>
                            </div>
                            <div class="activity-time">Yesterday</div>
                        </li>
                        <li class="activity-item">
                            <div class="activity-icon" style="background-color: rgba(247, 37, 133, 0.1); color: var(--danger);">
                                <i class="fas fa-stop-circle"></i>
                            </div>
                            <div class="activity-content">
                                <h4>Lecture Ended</h4>
                                <p>Physics - Mechanics class</p>
                            </div>
                            <div class="activity-time">Yesterday</div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <footer>
            <p>Teacher Dashboard &copy; <?php echo date('Y'); ?> Attendance System. All rights reserved.</p>
        </footer>
    </div>

    <script>
        // Attendance Chart
        const attendanceData = <?php echo json_encode($lecture_data); ?>;
        if (attendanceData.length > 0) {
            const attendanceCtx = document.getElementById('attendanceChart').getContext('2d');
            new Chart(attendanceCtx, {
                type: 'bar',
                data: {
                    labels: attendanceData.map(item => {
                        const parts = item.label.split(' ');
                        return parts[1] + ' (' + parts[2].replace(/[()]/g, '') + ')';
                    }),
                    datasets: [{
                        label: 'Attendance Rate (%)',
                        data: attendanceData.map(item => item.attendance),
                        backgroundColor: [
                            'rgba(67, 97, 238, 0.7)',
                            'rgba(76, 201, 240, 0.7)',
                            'rgba(248, 150, 30, 0.7)',
                            'rgba(247, 37, 133, 0.7)',
                            'rgba(111, 66, 193, 0.7)'
                        ],
                        borderColor: [
                            'rgba(67, 97, 238, 1)',
                            'rgba(76, 201, 240, 1)',
                            'rgba(248, 150, 30, 1)',
                            'rgba(247, 37, 133, 1)',
                            'rgba(111, 66, 193, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 100,
                            title: {
                                display: true,
                                text: 'Attendance Rate (%)'
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            mode: 'index',
                            intersect: false,
                            callbacks: {
                                label: function(context) {
                                    const index = context.dataIndex;
                                    return `${attendanceData[index].class}: ${context.parsed.y}%`;
                                }
                            }
                        }
                    }
                }
            });
        }

        // Lectures Chart (removed as it was not tied to real data)
    </script>
</body>
</html>
<?php include '../includes/footer.php'; ?>