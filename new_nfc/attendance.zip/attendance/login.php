<?php
include 'includes/db.php';
include 'includes/functions.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    echo "Username: $username, Password: $password<br>"; // Debug output
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    if ($user) {
        echo "User found, ID: " . $user['id'] . ", Password hash: " . $user['password'] . "<br>";
        if (password_verify($password, $user['password'])) {
            echo "Password verified successfully<br>";
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            redirect('dashboard.php');
        } else {
            echo "Password verification failed<br>";
            $error = "Invalid credentials";
        }
    } else {
        echo "No user found<br>";
        $error = "Invalid credentials";
    }
}
include 'includes/header.php';
?>
<h1 class="text-2xl">Login</h1>
<?php if (isset($error)): ?><p class="text-red-500"><?php echo $error; ?></p><?php endif; ?>
<form method="POST" class="space-y-4">
    <input type="text" name="username" placeholder="Username" class="border p-2 w-full">
    <input type="password" name="password" placeholder="Password" class="border p-2 w-full">
    <button type="submit" class="bg-blue-500 text-white p-2">Login</button>
</form>
<?php include 'includes/footer.php'; ?>