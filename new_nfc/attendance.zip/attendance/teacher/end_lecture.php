<?php
include '../includes/db.php';
include '../includes/functions.php';
if (!is_teacher()) redirect('../dashboard.php');

$teacher_id = get_teacher_id($pdo, $_SESSION['user_id']);
$active_lectures = $pdo->prepare("SELECT l.id, s.name as subject, c.name as class FROM lectures l JOIN assignments a ON l.assignment_id = a.id JOIN subjects s ON a.subject_id = s.id JOIN classes c ON a.class_id = c.id WHERE a.teacher_id = ? AND l.end_time IS NULL");
$active_lectures->execute([$teacher_id]);
$active_lectures = $active_lectures->fetchAll();

$success = $error = null;

// Handle GET for NFC/URL (auto-end specific lecture)
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['lecture_id'])) {
    $lecture_id = $_GET['lecture_id'];
    // Verify lecture belongs to teacher and is active
    $stmt = $pdo->prepare("SELECT l.id FROM lectures l JOIN assignments a ON l.assignment_id = a.id WHERE l.id = ? AND a.teacher_id = ? AND l.end_time IS NULL");
    $stmt->execute([$lecture_id, $teacher_id]);
    if ($stmt->fetch()) {
        $stmt = $pdo->prepare("UPDATE lectures SET end_time = NOW() WHERE id = ?");
        $stmt->execute([$lecture_id]);
        unset($_SESSION['active_lecture_id']); // Clear active lecture from session
        $success = "Lecture $lecture_id ended";
        header("Refresh:2; url=../dashboard.php");
    } else {
        $error = "Invalid or already ended lecture";
    }
}

// Handle POST from form (manual)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $lecture_id = $_POST['lecture_id'];
    $stmt = $pdo->prepare("UPDATE lectures SET end_time = NOW() WHERE id = ?");
    $stmt->execute([$lecture_id]);
    unset($_SESSION['active_lecture_id']); // Clear active lecture from session
    $success = "Lecture ended";
}

include '../includes/header.php';
?>
<h1 class="text-2xl">End Lecture</h1>
<?php if (isset($success)): ?><p class="text-green-500"><?php echo $success; ?></p><?php endif; ?>
<?php if (isset($error)): ?><p class="text-red-500"><?php echo $error; ?></p><?php endif; ?>
<form method="POST" class="space-y-4">
    <select name="lecture_id" class="border p-2 w-full" required>
        <?php foreach ($active_lectures as $l): ?>
            <option value="<?php echo $l['id']; ?>"><?php echo $l['subject'] . ' in ' . $l['class']; ?></option>
        <?php endforeach; ?>
    </select>
    <button type="submit" class="bg-red-500 text-white p-2">End</button>
</form>
<?php include '../includes/footer.php'; ?>