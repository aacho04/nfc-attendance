<?php
include '../includes/db.php';
include '../includes/functions.php';
if (!is_teacher()) redirect('../dashboard.php');

$teacher_id = get_teacher_id($pdo, $_SESSION['user_id']);
$success = $error = null;

// Handle GET for NFC/URL (auto-start)
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_GET['assignment_id'])) {
        $assignment_id = $_GET['assignment_id'];
        // Verify assignment belongs to teacher
        $stmt = $pdo->prepare("SELECT id FROM assignments WHERE id = ? AND teacher_id = ?");
        $stmt->execute([$assignment_id, $teacher_id]);
        if ($stmt->fetch()) {
            $stmt = $pdo->prepare("INSERT INTO lectures (assignment_id, start_time) VALUES (?, NOW())");
            $stmt->execute([$assignment_id]);
            $lecture_id = $pdo->lastInsertId();
            $_SESSION['active_lecture_id'] = $lecture_id; // Set active lecture in session
            $success = "Lecture started. ID: $lecture_id";
            header("Refresh:2; url=../dashboard.php");
        } else {
            $error = "Invalid assignment for this teacher";
        }
    } elseif (isset($_GET['class_id'])) {
        $class_id = $_GET['class_id'];
        // Find assignments for teacher in this class
        $stmt = $pdo->prepare("SELECT id FROM assignments WHERE teacher_id = ? AND class_id = ?");
        $stmt->execute([$teacher_id, $class_id]);
        $assignments_in_class = $stmt->fetchAll(PDO::FETCH_COLUMN);
        $count = count($assignments_in_class);
        
        if ($count == 1) {
            // Auto-start the only assignment
            $assignment_id = $assignments_in_class[0];
            $stmt = $pdo->prepare("INSERT INTO lectures (assignment_id, start_time) VALUES (?, NOW())");
            $stmt->execute([$assignment_id]);
            $lecture_id = $pdo->lastInsertId();
            $_SESSION['active_lecture_id'] = $lecture_id; // Set active lecture in session
            $success = "Lecture started in class $class_id. ID: $lecture_id";
            header("Refresh:2; url=../dashboard.php");
        } elseif ($count == 0) {
            $error = "No assignments for you in this class";
        } else {
            $error = "Multiple subjects in this class—choose one below";
        }
    }
}

// Handle POST from form (manual)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $assignment_id = $_POST['assignment_id'];
    $stmt = $pdo->prepare("INSERT INTO lectures (assignment_id, start_time) VALUES (?, NOW())");
    $stmt->execute([$assignment_id]);
    $lecture_id = $pdo->lastInsertId();
    $_SESSION['active_lecture_id'] = $lecture_id; // Set active lecture in session
    $success = "Lecture started. ID: $lecture_id";
}

// Fetch all assignments for form
$assignments = $pdo->prepare("SELECT a.id, s.name as subject, c.name as class FROM assignments a JOIN subjects s ON a.subject_id = s.id JOIN classes c ON a.class_id = c.id WHERE teacher_id = ?");
$assignments->execute([$teacher_id]);
$assignments = $assignments->fetchAll();

include '../includes/header.php';
?>
<h1 class="text-2xl">Start Lecture</h1>
<?php if (isset($success)): ?><p class="text-green-500"><?php echo $success; ?></p><?php endif; ?>
<?php if (isset($error)): ?><p class="text-red-500"><?php echo $error; ?></p><?php endif; ?>
<form method="POST" class="space-y-4">
    <select name="assignment_id" class="border p-2 w-full" required>
        <?php foreach ($assignments as $a): ?>
            <option value="<?php echo $a['id']; ?>"><?php echo $a['subject'] . ' in ' . $a['class']; ?></option>
        <?php endforeach; ?>
    </select>
    <button type="submit" class="bg-blue-500 text-white p-2">Start (Simulate NFC Tap)</button>
</form>
<?php include '../includes/footer.php'; ?>