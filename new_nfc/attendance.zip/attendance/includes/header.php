<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance System</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body>
<header class="bg-gray-800 text-white p-4">
    <nav class="flex space-x-4">
        <a href="index.php" class="hover:underline">Home</a>
        <?php if (is_logged_in()): ?>
            <a href="<?php echo is_admin() ? '../dashboards/admin_dashboard.php' : (is_teacher() ? '../dashboards/teacher_dashboard.php' : '../dashboards/student_dashboard.php'); ?>" class="hover:underline">Dashboard</a>
            <a href="../logout.php" class="hover:underline">Logout</a>
        <?php else: ?>
            <a href="login.php" class="hover:underline">Login</a>
            <a href="register.php" class="hover:underline">Register</a>
        <?php endif; ?>
    </nav>
</header>
<main class="container mx-auto p-4">