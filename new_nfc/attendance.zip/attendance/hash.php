<?php
echo password_hash('student', PASSWORD_DEFAULT);
?>